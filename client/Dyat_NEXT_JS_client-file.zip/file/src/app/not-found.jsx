import BreadcrumbOne from "@/components/BreadcrumbOne";
import ErrorInner from "@/components/ErrorInner";
import FooterOne from "@/components/FooterOne";
import HeaderTwo from "@/components/HeaderTwo";

export default function NotFound() {
  return (
    <section className='not_found'>
      {/* HeaderTwo */}
      <HeaderTwo />

      {/* BreadcrumbOne */}
      <BreadcrumbOne title='Error' theme='404' inner='Error' />

      {/* ErrorInner */}
      <ErrorInner />

      {/* FooterOne */}
      <FooterOne />
    </section>
  );
}
